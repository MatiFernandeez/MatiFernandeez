package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.entities.Radio;

public class AutoClasico extends Vehiculo {
	 String marca;
	 String color;
	 String modelo;
	 int precio;
	 Radio radio;
	 String marcaradio;
	
	/**
	 * Constructor sin radio ni precio  
	 */
	
	public AutoClasico(String marca, String color, String modelo) {
		super(marca, modelo, color);
		this.marca = marca;
		this.color = color;
		this.modelo = modelo;
	}
	/**
	 * 
	 * Constructor con precio
	 */
	
	public AutoClasico(String marca, String color, String modelo, int precio) {
		super(marca, color, modelo, precio);
		this.marca = marca;
		this.color = color;
		this.modelo = modelo;
		this.precio = precio;
	}
	
	/**
	 * Constructor con radio
	 */
	public AutoClasico(String modelo, String color, String marca, int precio, String radio) {
		super(modelo, color, marca);
		this.color = color;
		this.marca = marca;
		this.modelo = modelo;
		this.precio = precio;
		this.radio  =new Radio(marcaradio);
	}
	
}
		
	
	
	
	
	
	
	
