package ar.org.centro8.curso.java.entities;



public class AutoNuevo extends Vehiculo {
	 String modelo;
	 String marca;
	 String color;
	 Radio radio;
	 int precio;
	 String marcaradio;
	
	
	
	/**
	 * Constructor sin precio
	 */
	public AutoNuevo(String modelo, String marca, String color) {
		super(modelo, marca, color);
		this.modelo = modelo;
		this.marca = marca;
		this.color = color;
		this.radio =new Radio(marcaradio);
	}

	/*
	 * Constructor con precio
	 */
	public AutoNuevo(String modelo, String marca, String color, String marcaradio, int precio) {
		super(modelo, marca, color, precio);
		this.modelo = modelo;
		this.marca = marca;
		this.color = color;
		this.radio =new Radio(marcaradio);
		this.precio = precio;
	}
	
}

	
	
	
	

