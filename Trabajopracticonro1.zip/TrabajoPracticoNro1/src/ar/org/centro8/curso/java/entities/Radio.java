package ar.org.centro8.curso.java.entities;

public class Radio {
	
	private String marcaradio;

	public Radio(String marcaradio) {
		this.marcaradio = marcaradio;
	}
	
	public String getMarcaradio() {
		return marcaradio;
	
	}

	@Override
	public String toString() {
		return "Radio [marcaradio=" + marcaradio + "]";
	}
	
}
