package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Vehiculo;
import ar.org.centro8.curso.java.entities.AutoClasico;

public class TestAutos {
	
	public static void main(String [] args) {
		
		//Auto clasico sin radio
		AutoClasico ac1= new AutoClasico("Chevy", "Chevrolet", "Amarillo");
		System.out.println("---AutoCLasico ac1---");
		System.out.println(ac1.toString());
		
		//Agrego una radio
		ac1.setRadio("Sony");
		System.out.println(ac1.toString());
		
		//Auto Nuevo Sin radio
		AutoNuevo an1= new AutoNuevo("DB11" , "Verde", "Aston Martin", null, 0);
		System.out.println("---AutoNuevo an1---");
		System.out.println(an1.toString());
		
		//Agrego la radio
		an1.setRadio("Philips")	;
		System.out.println(an1.toString());
		
		//Auto Clasico con precio
		AutoClasico ac2= new AutoClasico("Falcon" , "Azul", "Ford",450000);
		System.out.println("---AutoClasico ac2---");
		System.out.println(ac2.toString());
		
		//Auto nuevo con precio y radio
		AutoNuevo an2= new AutoNuevo("A4" , "Negro", "Audi",null, 2200000);
		System.out.println("---AutoNuevo an2---");
		an2.setRadio("Sony");
		System.out.println(an2.toString());
	}
	
}

	
	


