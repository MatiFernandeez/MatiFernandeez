package ar.org.centro8.curso.java.entities;

public abstract class Vehiculo {
	private String modelo;
	private String color;
	private String marca;
	private int precio;
	private Radio radio;
	
	
	public Vehiculo(String modelo, String color, String marca) {
		super();
		this.modelo = modelo;
		this.color = color;
		this.marca = marca;
	}

	public Vehiculo(String modelo, String color, String marca, int precio) {
		super();
		this.modelo = modelo;
		this.color = color;
		this.marca = marca;
		this.precio = precio;
		
	}

	public String getModelo() {
		return modelo;
	}

	public String getColor() {
		return color;
	}

	public String getMarca() {
		return marca;
	}

	public int getPrecio() {
		return precio;
	}

	public Radio getRadio() {
		return radio;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	
	
	public void setRadio(String radio) {
		this.radio =new Radio(radio);
		
	}

	@Override
	public String toString() {
		return "Vehiculo [modelo=" + modelo + ", color=" + color + ", marca=" + marca + ", precio=" + precio
				+ ", radio=" + radio + "]";
	
	}
	
}

	

	
	

	
	

	
	
	

	
	

	
	

	
	

	
	


	

	
	
	
	
	

