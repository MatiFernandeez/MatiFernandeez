package ar.org.centro8.curso.java.entities;

public abstract class Vehiculos {
	private String marca;
	private String modelo;
	private int puertas;
	private double cilindrada;
	private double precio;
	
	
	public Vehiculos(String marca, String modelo, int puertas, double precio) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.puertas = puertas;
		this.precio = precio;
	}


	public Vehiculos(String marca, String modelo,double cilindrada, double precio) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.cilindrada = cilindrada;
		this.precio = precio;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public int getPuertas() {
		return puertas;
	}


	public void setPuertas(int puertas) {
		this.puertas = puertas;
	}


	public double getCilindrada() {
		return cilindrada;
	}


	public void setCilindrada(double cilindrada) {
		this.cilindrada = cilindrada;
	}


	public double getPrecio() {
		return precio;
	}


	public void setPrecio(double precio) {
		this.precio = precio;
	}


	@Override
	public String toString() {
		return "Vehiculos [marca=" + marca + ", modelo=" + modelo + ", puertas=" + puertas + ", cilindrada="
				+ cilindrada + ", precio=" + precio + "]";
	}
}
	
	
		
	
	

