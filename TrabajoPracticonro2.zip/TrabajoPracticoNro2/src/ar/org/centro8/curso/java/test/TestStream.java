package ar.org.centro8.curso.java.test;

import java.util.Comparator;
import java.util.List;
import ar.org.centro8.curso.java.entities.Vehiculo;


public class TestStream {
	
	public static void main(String[] args) {
		System.out.println("Listados");
		List<Vehiculo>list=List.of(
				new Vehiculo("Peugeot","208",5, 250.00000, 0),
				new Vehiculo("Peugeot","206",4,200.00000, 0),
				new Vehiculo("Yamaha","YBR",0,80.500,160),
				new Vehiculo("Honda","Titan",0, 60.00000,125)
				);
		
		list.forEach(System.out::println);
		
		System.out.println("*******************************");
		System.out.println("Precio de Mayor a Menor");
		
		list
		
		   .stream()
        .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed().thenComparing(Vehiculo::getMarca).thenComparing(Vehiculo::getModelo))
        .forEach(System.out::println);
		
		System.out.println("*******************************");
		System.out.println("Por orden natural");
		list
            .stream()
            .sorted()
            .forEach(System.out::println);
		
		System.out.println("********************************");
		System.out.println("Vehiculo que contiene la letra Y");
		
		list
             .stream()
             .filter(v->v.getMarca().toLowerCase().startsWith("y"))
             .forEach(System.out::println);
		
		System.out.println("**********************************");
		System.out.println("Vehiculo mas caro");
		list
		     .stream()
		     .filter(v->v.getMarca().endsWith("t")
		    		 && v.getPuertas()>4)
		     .forEach(System.out::println);
		
		System.out.println("***********************************");
		System.out.println("Vehiculo mas barato");
		list
		      .stream()
		      .filter(v->v.getMarca().toLowerCase().startsWith("h"))	    		
		      .forEach(System.out::println);
		
	}
}


