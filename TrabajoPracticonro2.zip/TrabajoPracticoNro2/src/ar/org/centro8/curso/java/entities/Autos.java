package ar.org.centro8.curso.java.entities;

public class Autos extends Vehiculos {
	private String marca;
	private String modelo;
	private double precio;
	private int puertas;
	
	
	public Autos(String marca, String modelo, int puertas, double precio, String marca2, String modelo2, double precio2,
			int puertas2) {
		super(marca, modelo, puertas, precio);
		marca = marca2;
		modelo = modelo2;
		precio = precio2;
		puertas = puertas2;

	}
	
}
