package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.Motos;
import ar.org.centro8.curso.java.entities.Autos;

public class TestVehiculos {
	
	public static void main(String [] args) {
		
		
		//Autos con precio
		Autos au1 = new Autos("Peugeot" , "206",4,200.000,null, null, 00, 0);
		System.out.println("---Autos an1---");
		System.out.println(au1.toString());
		
		//Autos2 con precio
		Autos au2 = new Autos("Peugeot" , "208",5,250.00000, null, null, 0, 0);
		System.out.println("---Autos an2---");
		System.out.println(au2.toString());
		
		//Motos con precio
		Motos mo1 = new Motos("Honda" , "Titan",125, null, null, 0);
		System.out.println("---Motos mo1---");
		mo1.setPrecio(60.000);
		System.out.println(mo1.toString());	
		
		//Motos2 con precio
		Motos mo2 = new Motos("Yahama" , "YBR" ,160, null, null, 0);
		System.out.println("---Motos mo2---");
		mo2.setPrecio(80.500);
		System.out.println(mo2.toString());
	}
}
