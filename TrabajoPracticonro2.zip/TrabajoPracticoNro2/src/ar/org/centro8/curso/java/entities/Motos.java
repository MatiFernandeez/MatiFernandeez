package ar.org.centro8.curso.java.entities;

public class Motos extends Vehiculos {
	private String marca;
	private String modelo;
	private double precio;
	private double cilindrada;
	
	
	
	
	public Motos(String marca, String modelo, double precio, String marca2, String modelo2, double precio2) {
		super(marca, modelo,precio, precio2);
		marca = marca2;
		modelo = modelo2;
		precio = precio2;
		
	}

}
	
	
	

