package ar.org.centro8.curso.java.entities;

public class Vehiculo implements Comparable<Vehiculo>{
	private String marca;
	private String modelo;
	private int puertas;
	private Double precio;
	double cilindrada;
	
	
	public Vehiculo(String marca, String modelo, int puertas, Double precio, double cilindrada) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.puertas = puertas;
		this.precio = precio;
		this.cilindrada = cilindrada;
	}


	@Override
	public String toString() {
		return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", puertas=" + puertas + ", precio=" + precio
				+ ", cilindrada=" + cilindrada + "]";
	}


	@Override
	public int compareTo(Vehiculo vehiculo) {
		String thisVehiculo = this.getMarca()+","+this.getModelo()+","+this.getPuertas()+","+this.getCilindrada();
		String paraVehiculo = vehiculo.getMarca()+","+vehiculo.getModelo()+","+vehiculo.getPuertas()+","+vehiculo.getCilindrada();
		return thisVehiculo.compareTo(paraVehiculo);
	}


	@Override
	public int hashCode() {
		return toString().hashCode();
		
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		return this.hashCode()==obj.hashCode();
		
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public int getPuertas() {
		return puertas;
	}


	public void setPuertas(int puertas) {
		this.puertas = puertas;
	}


	public Double getPrecio() {
		return precio;
	}


	public void setPrecio(Double precio) {
		this.precio = precio;
	}


	public double getCilindrada() {
		return cilindrada;
	}


	public void setCilindrada(double cilindrada) {
		this.cilindrada = cilindrada;
	}
}
	



