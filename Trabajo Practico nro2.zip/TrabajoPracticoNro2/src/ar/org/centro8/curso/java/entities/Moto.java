package ar.org.centro8.curso.java.entities;

public class Moto extends Vehiculo {
	private String cilindrada;

	public Moto(String marca, String modelo,String cilindrada,Double precio) {
		super(marca, modelo, precio);
		this.cilindrada = cilindrada;
	}

	@Override
	public String toString() {
		return super.toString() +"// Cilindrada: "+cilindrada+"// Precio: $" +getPrecioFormat();
	}
	
	public String getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(String cilindrada) {
		this.cilindrada = cilindrada;
	}	
}
	
	
	
	
	
	

	
	
	
			
	


	
	
	

