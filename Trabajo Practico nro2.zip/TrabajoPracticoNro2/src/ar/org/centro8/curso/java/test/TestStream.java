package ar.org.centro8.curso.java.test;

import java.util.Comparator;
import java.util.List;
import ar.org.centro8.curso.java.entities.Vehiculo;
import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;

public class TestStream {
	
	public static void main(String[] args) {
		System.out.println("Listados");
		List<Vehiculo> list = cargarListados();
		
		list.forEach(System.out::println);
		
		separador();
		System.out.println("Precio de Mayor a Menor");
		
		ordenNatural(list);
		
		separador();
		
		ordenxPrecioMax(list);
				    
		ordenxPrecioMin(list);
		
		vehiculoLetray(list);		
	}

	private static void vehiculoLetray(List<Vehiculo> list) {
		System.out.println("Vehiculo que contiene la letra Y");

		list
             .stream()
             .filter(v->v.getModelo().toLowerCase().startsWith("y"))
             .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()+" "+v.getPrecioFormat()));
	}

	private static void ordenxPrecioMin(List<Vehiculo> list) {
		double precioMin = list
				.stream()
				.min(Comparator.comparingDouble(Vehiculo::getPrecio))
				.get()
				.getPrecio();
		list
		.stream()
		.filter(v->v.getPrecio()==precioMin)
		.forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
	}

	private static void ordenxPrecioMax(List<Vehiculo> list) {
		System.out.println("Vehiculo mas caro y mas barato");
		double precioMax = list
				.stream()
				.max(Comparator.comparingDouble(Vehiculo::getPrecio))				
				.get()
				.getPrecio();
		list
		.stream()
		.filter(v->v.getPrecio()==precioMax)
		.forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
	}

	private static void separador() {
		System.out.println("=============================");
	}

	private static void ordenNatural(List<Vehiculo> list) {
		list
		
		   .stream()
        .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed().thenComparing(Vehiculo::getMarca).thenComparing(Vehiculo::getModelo))
        .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
		
		separador();
		System.out.println("Por orden natural");
		list
            .stream()
            .sorted()
            .forEach(System.out::println);
	}

	private static List<Vehiculo> cargarListados() {
		List<Vehiculo>list=List.of(
				new Auto("Peugeot","206",4,200000.00),
				new Moto("Honda","Titan","125c",60000.00),
				new Auto("Peugeot","208",5,250000.00),
				new Moto("Yamaha","YBR","160c",80500.50)
				);
		return list;
	}
}


